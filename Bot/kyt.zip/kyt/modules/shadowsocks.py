from kyt import *

@bot.on(events.CallbackQuery(data=b'create-shadowsocks'))
async def create_shadowsocks(event):
	async def create_shadowsocks_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**ᴜsᴇʀɴᴀᴍᴇ:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as pw:
			await event.respond("**ǫᴜᴏᴛᴀ:**")
			pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			pw = (await pw).raw_text
		async with bot.conversation(chat) as exp:
			await event.respond("**ᴄʜᴏᴏsᴇ ᴇxᴘɪʀʏ ᴅᴀʏ**",buttons=[
[Button.inline(" 3 ᴅᴀʏ ","3"),
Button.inline(" 7 ᴅᴀʏ","7")],
[Button.inline(" 30 ᴅᴀʏ ","30"),
Button.inline(" 60 ᴅᴀʏ ","60")]])
			exp = exp.wait_event(events.CallbackQuery)
			exp = (await exp).data.decode("ascii")
		await event.edit("ᴘʀᴏᴄᴇssɪɴɢ.")
		await event.edit("ᴘʀᴏᴄᴇssɪɴɢ..")
		await event.edit("ᴘʀᴏᴄᴇssɪɴɢ...")
		await event.edit("ᴘʀᴏᴄᴇssɪɴɢ....")
		time.sleep(1)
		await event.edit("`ᴘʀᴏᴄᴇssɪɴɢ ᴄʀᴀᴛᴇ ᴘʀᴇᴍɪᴜᴍ ᴀᴄᴄᴏᴜɴᴛ`")
		time.sleep(1)
		await event.edit("`ᴘʀᴏᴄᴇssɪɴɢ... 0%\n《 ▒▒▒▒▒▒▒▒▒▒▒▒》 `")
		time.sleep(1)
		await event.edit("`ᴘʀᴏᴄᴇssɪɴɢ... 10%\n《 █▒▒▒▒▒▒▒▒▒▒▒》`")
		time.sleep(1)
		await event.edit("`ᴘʀᴏᴄᴇssɪɴɢ... 30%\n《 ███▒▒▒▒▒▒▒▒▒》`")
		time.sleep(1)
		await event.edit("`ᴘʀᴏᴄᴇssɪɴɢ... 20%\n《 ████▒▒▒▒▒▒▒▒》`")
		time.sleep(1)
		await event.edit("`ᴘʀᴏᴄᴇssɪɴɢ... 36%\n《 ██████▒▒▒▒▒▒》 `")
		time.sleep(1)
		await event.edit("`ᴘʀᴏᴄᴇssɪɴɢ... 52%\n《 ███████▒▒▒▒▒》 `")
		time.sleep(1)
		await event.edit("`ᴘʀᴏᴄᴇssɪɴɢ... 84%\n《 █████████▒▒▒》`")
		time.sleep(0)
		await event.edit("`ᴘʀᴏᴄᴇssɪɴɢ... 100%\n《 ████████████》`")
		time.sleep(1)
		await event.edit("`Tunggu... Sebentar`")
		cmd = f'printf "%s\n" "{user}" "{exp}" "{pw}" | addss'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**ᴜsᴇʀ ᴀʟʀᴇᴀᴅʏ ᴇxɪsᴛ**")
		else:
			today = DT.date.today()
			later = today + DT.timedelta(days=int(exp))
			x = [x.group() for x in re.finditer("ss://(.*)",a)]
			print(x)
			# remarks = re.search("#(.*)",x[0]).group(1)
			# domain = re.search("@(.*?):",x[0]).group(1)
			uuid = re.search("ss://(.*?)@",x[0]).group(1)
			# path = re.search("path=(.*)&",x[0]).group(1)
			msg = f"""
𝐓𝐞𝐫𝐢𝐦𝐚 𝐤𝐚𝐬𝐢𝐡 𝐭𝐞𝐥𝐚𝐡 𝐦𝐞𝐧𝐠𝐠𝐮𝐧𝐚𝐤𝐚𝐧 𝐬𝐜 𝐜𝐫𝐞𝐚𝐝𝐢𝐭 𝐛𝐲 𝐪𝐮𝐞𝐞𝐧 𝐭𝐮𝐧𝐧𝐞𝐥𝐢𝐧𝐠
"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await create_shadowsocks_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'cek-shadowsocks'))
async def cek_shadowsocks(event):
	async def cek_shadowsocks_(event):
		cmd = 'bot-cek-ss'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""

{z}

**sʜᴏᴡs ʟᴏɢɢᴇᴅ ɪɴ ᴜsᴇʀs sʜᴀᴅᴏᴡsᴏᴄᴋs**
**» 🤖@Queen_Storeb**
""",buttons=[[Button.inline("‹ ᴍᴀɪɴ ᴍᴇɴᴜ ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await cek_shadowsocks_(event)
	else:
		await event.answer("ᴀᴄᴄᴇss ᴅᴇɴɪᴇᴅ",alert=True)

@bot.on(events.CallbackQuery(data=b'delete-shadowsocks'))
async def delete_shadowsocks(event):
	async def delete_shadowsocks_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**Username:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		cmd = f'printf "%s\n" "{user}" | del-ss'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Not Found**")
		else:
			msg = f"""**sᴜᴄᴄᴇssғᴜʟʟʏ ᴅᴇʟᴇᴛᴇᴅ**"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await delete_shadowsocks_(event)
	else:
		await event.answer("ᴀᴋsᴇs ᴅɪᴛᴏʟᴀᴋ",alert=True)

@bot.on(events.CallbackQuery(data=b'trial-shadowsocks'))
async def trial_shadowsocks(event):
	async def trial_shadowsocks_(event):
		async with bot.conversation(chat) as exp:
			await event.respond("**Choose Expiry Minutes**",buttons=[
[Button.inline(" 10 ᴍᴇɴɪᴛ ","10"),
Button.inline(" 15 ᴍᴇɴɪᴛ","15")],
[Button.inline(" 30 ᴍᴇɴɪᴛ ","30"),
Button.inline(" 60 ᴍᴇɴɪᴛ ","60")]])
			exp = exp.wait_event(events.CallbackQuery)
			exp = (await exp).data.decode("ascii")
		await event.edit("ᴘʀᴏᴄᴇssɪɴɢ.")
		await event.edit("ᴘʀᴏᴄᴇssɪɴɢ..")
		await event.edit("ᴘʀᴏᴄᴇssɪɴɢ...")
		await event.edit("ᴘʀᴏᴄᴇssɪɴɢ....")
		time.sleep(1)
		await event.edit("`ᴘʀᴏᴄᴇssɪɴɢ ᴄʀᴀᴛᴇ ᴘʀᴇᴍɪᴜᴍ ᴀᴄᴄᴏᴜɴᴛ`")
		time.sleep(1)
		await event.edit("`ᴘʀᴏᴄᴇssɪɴɢ... 0%\n《 ▒▒▒▒▒▒▒▒▒▒▒▒》 `")
		time.sleep(1)
		await event.edit("`ᴘʀᴏᴄᴇssɪɴɢ... 10%\n《 █▒▒▒▒▒▒▒▒▒▒▒》`")
		time.sleep(1)
		await event.edit("`ᴘʀᴏᴄᴇssɪɴɢ... 30%\n《 ███▒▒▒▒▒▒▒▒▒》`")
		time.sleep(1)
		await event.edit("`ᴘʀᴏᴄᴇssɪɴɢ... 20%\n《 ████▒▒▒▒▒▒▒▒》`")
		time.sleep(1)
		await event.edit("`ᴘʀᴏᴄᴇssɪɴɢ... 36%\n《 ██████▒▒▒▒▒▒》 `")
		time.sleep(1)
		await event.edit("`ᴘʀᴏᴄᴇssɪɴɢ... 52%\n《 ███████▒▒▒▒▒》 `")
		time.sleep(1)
		await event.edit("`ᴘʀᴏᴄᴇssɪɴɢ... 84%\n《 █████████▒▒▒》`")
		time.sleep(0)
		await event.edit("`ᴘʀᴏᴄᴇssɪɴɢ... 100%\n《 ████████████》`")
		time.sleep(1)
		await event.edit("`Tunggu... Sebentar`")
		cmd = f'printf "%s\n" "{exp}" | trialss'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Already Exist**")
		else:
			#today = DT.date.today()
			#later = today + DT.timedelta(days=int(exp))
			x = [x.group() for x in re.finditer("ss://(.*)",a)]
			print(x)
			remarks = re.search("#(.*)",x[0]).group(1)
			# domain = re.search("@(.*?):",x[0]).group(1)
			uuid = re.search("ss://(.*?)@",x[0]).group(1)
			# path = re.search("path=(.*)&",x[0]).group(1)
			msg = f"""
𝐓𝐞𝐫𝐢𝐦𝐚 𝐤𝐚𝐬𝐢𝐡 𝐭𝐞𝐥𝐚𝐡 𝐦𝐞𝐧𝐠𝐠𝐮𝐧𝐚𝐤𝐚𝐧 𝐬𝐜 𝐜𝐫𝐞𝐚𝐝𝐢𝐭 𝐛𝐲 𝐪𝐮𝐞𝐞𝐧 𝐭𝐮𝐧𝐧𝐞𝐥𝐢𝐧𝐠
"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await trial_shadowsocks_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'shadowsocks'))
async def shadowsocks(event):
	async def shadowsocks_(event):
		inline = [
[Button.inline(" ᴛʀɪᴀʟ sʜᴅᴡsᴄsᴋ ","trial-shadowsocks"),
Button.inline(" ᴄʀᴇᴀᴛᴇ sʜᴅᴡsᴄsᴋ ","create-shadowsocks")],
[Button.inline(" ᴄʜᴇᴄᴋ sʜᴅᴡsᴄsᴋ ","cek-shadowsocks"),
Button.inline(" ᴅᴇʟᴇᴛᴇ sʜᴅᴡsᴄsᴋ ","delete-shadowsocks")],
[Button.inline("‹ ᴍᴀɪɴ ᴍᴇɴᴜ ›","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		msg = f"""
◆━━━━━━━━━━━━━━━◆ 
** sʜᴅᴡsᴋ ᴍᴀɴᴀɢᴇʀ **
◆━━━━━━━━━━━━━━━◆
 **» sᴇʀᴠɪᴄᴇ:** `SHADOWSOCKS`
 **» ʜᴏsᴛɴᴀᴍᴇ/ɪᴘ:** `{DOMAIN}`
 **» ɪsᴘ:** `{z["isp"]}`
 **» ᴄᴏᴜɴᴛʀʏ:** `{z["country"]}`
 **» @Queen_Storeb**
◆━━━━━━━━━━━━━━━◆
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await shadowsocks_(event)
	else:
		await event.answer("Access Denied",alert=True)
